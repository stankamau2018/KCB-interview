// I have implemented using kotlin gradle
Brief desc:

have 3 directories Controller(Presentation),Domain(Logic layer), Data(connection with database)

Name: Stanley Kamau
email:skamau45@gmail.com
phone:0725764230