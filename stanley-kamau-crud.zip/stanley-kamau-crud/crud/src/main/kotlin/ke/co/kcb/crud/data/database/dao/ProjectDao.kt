package ke.co.kcb.crud.data.database.dao

import ke.co.kcb.crud.data.database.dbo.ProjectDbo
import ke.co.kcb.crud.data.database.dbo.TaskDbo
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
interface ProjectDao: CrudRepository<ProjectDbo,Long> {

    @Query("select p from ProjectDbo p where p.id=:id")
    fun fetchProjectById(@Param("id") id:Long): ProjectDbo

    @Query("select p from ProjectDbo p")
    fun fetchAllProjects(): List<ProjectDbo>


}

