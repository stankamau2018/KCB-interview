package ke.co.kcb.crud.data.database.dao

import ke.co.kcb.crud.data.database.dbo.Status
import ke.co.kcb.crud.data.database.dbo.TaskDbo
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import java.util.Date

@Repository
interface TaskDao: CrudRepository<TaskDbo, Long> {

    @Query("select t from TaskDbo t where t.id=:id")
    fun findTaskById(@Param("id") id:Long): TaskDbo

    @Query("""
    select t from TaskDbo t 
    where (:status is null or t.status = :status) 
    and (:dueDate is null or t.dueDate = :dueDate)
""")
    fun findTasksByStatusAndDueDate(
        @Param("status") status: Status?,
        @Param("dueDate") dueDate: Date?
    ): List<TaskDbo>
}
