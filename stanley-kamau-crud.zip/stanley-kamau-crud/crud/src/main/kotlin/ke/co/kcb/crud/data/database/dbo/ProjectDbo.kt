package ke.co.kcb.crud.data.database.dbo

import jakarta.persistence.*

@Entity
@Table(name = "project")
data class ProjectDbo(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id") val id: Long = 0,
    @Column(name = "name") val name: String? = null,
    @Column(name = "description") val description: String?=null,
)
