package ke.co.kcb.crud.data.database.dbo

import jakarta.persistence.*
import sun.jvm.hotspot.debugger.cdbg.EnumType
import java.util.Date

@Entity
@Table(name = "task")
data class TaskDbo(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id") val id: Long = 0,
    @Column(name = "title") val title: String? = null,
    @Column(name = "description") val description: String?=null,
    @Enumerated(EnumType.STRING)
    @Column(name = "status")  val status: Status = Status.TO_DO,
    @Column(name = "due-date") val dueDate: Date,
    @ManyToOne
    @JoinColumn(name = "project-id", referencedColumnName = "Id", nullable = false)
    val project: ProjectDbo

)
enum class Status {
    TO_DO,
    IN_PROGRESS,
    DONE,
    DELETE //added this
}
