package ke.co.kcb.crud.data.repository

import ke.co.kcb.crud.data.database.dao.ProjectDao
import ke.co.kcb.crud.data.database.dao.TaskDao
import ke.co.kcb.crud.data.database.dbo.ProjectDbo
import ke.co.kcb.crud.data.database.dbo.Status
import ke.co.kcb.crud.data.database.dbo.TaskDbo
import ke.co.kcb.crud.domain.entity.Project
import ke.co.kcb.crud.domain.entity.Task
import ke.co.kcb.crud.domain.repository.ProjectRepository
import ke.co.kcb.crud.presentatation.Request.ProjectRequest
import ke.co.kcb.crud.presentatation.Request.TaskRequest
import ke.co.kcb.crud.presentatation.SuccessResponse
import ke.co.kcb.crud.util.DBException
import ke.co.kcb.crud.util.NotFoundException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.util.Date

@Component
class ProjectRepositoryImpl(@Autowired val projectDao: ProjectDao,
                            @Autowired val taskDao: TaskDao): ProjectRepository {
    override fun fetchAllProjects(): List<Project> {
        return try {
            // Fetch ProjectDbo list from DAO
            val projectsDbo = projectDao.fetchAllProjects()

            // Map ProjectDbo to Project
            projectsDbo.map { projectDbo ->
                Project(
                    id = projectDbo.id,
                    name = projectDbo.name ?: "", // Although I will take care no null fields will be saved
                    description = projectDbo.description ?: "" // Although I will take care no null fields will be saved
                )
            }
        } catch (e: Exception) {
            throw DBException("Something went wrong fetching projects::: $e")
        }
    }


    override fun fetchProjectById(id: Long): Project {
        return try{
            //fetch ProjectDbo from DAO
      val projectDbo = projectDao.fetchProjectById(id)
            //Map ProjectDbo to Project
            Project(
                id = projectDbo.id,
                name = projectDbo.name ?: "",
                description = projectDbo.description ?: ""
            )
        } catch (e: Exception) {
            throw DBException("Something went wrong fetching project by id $id::: $e")
        }
    }

    override fun fetchTasksByStatusAndDate(status: String, dueDate: Date): List<Task> {
        return try {

            val tasksDbo = taskDao.findTasksByStatusAndDueDate(Status.valueOf(status), dueDate)


            tasksDbo.map { dbo ->
                Task(
                    id = dbo.id,
                    title = dbo.title ?: "",
                    description = dbo.description ?: "",
                    status = dbo.status.name,
                    dueDate = dbo.dueDate,
                    projectId = dbo.project.id
                )
            }
        } catch (e: IllegalArgumentException) {
            throw IllegalArgumentException("Invalid status: $status", e)
        } catch (e: Exception) {
            throw DBException("Failed to fetch tasks by status and due date ::: $e")
        }
    }


    override fun createProject(projectRequest: ProjectRequest): SuccessResponse {
        return try {

            val dbo = ProjectDbo(
                id = 0L,
                name = projectRequest.name,
                description = projectRequest.description
            )
            projectDao.save(dbo)
            SuccessResponse(
                status = "SUCCESS",
                message = "Project created successfully with name: ${projectRequest.name}"
            )
        } catch (e: Exception) {

            throw DBException("Failed to create project::: $e")
        }
    }

    override fun createProjectTask(projectId: Long, taskRequest: TaskRequest): SuccessResponse {
        return try {
            // Check if the project exists
            val project = projectDao.fetchProjectById(projectId)
                ?: throw NotFoundException("Project with ID $projectId not found")

            val taskDbo = TaskDbo(
                id = 0L, // Default ID, assuming auto-generated
                title = taskRequest.title,
                description = taskRequest.description,
                status = taskRequest.status,
                dueDate = taskRequest.dueDate,
                project = project
            )

            taskDao.save(taskDbo)
            SuccessResponse(
                status = "SUCCESS",
                message = "Task created successfully for project ID: $projectId"
            )
        } catch (e: NotFoundException) {
            throw NotFoundException("Project $projectId not found")
        } catch (e: Exception) {
            throw DBException("Failed to create task for project ID: $projectId", e)
        }
    }

    override fun updateProjectTask(taskId: Long, taskRequest: TaskRequest): SuccessResponse {
        return try {
            // Fetch the existing task
            val oldTask = taskDao.findTaskById(taskId)
                ?: throw NotFoundException("Task with ID $taskId not found")

            // Update the task fields
            val updatedTask = oldTask.copy(
                title = taskRequest.title,
                description = taskRequest.description,
                status = taskRequest.status,
                dueDate = taskRequest.dueDate
            )

            // Save the updated task
            taskDao.save(updatedTask)

            // Return success response
            SuccessResponse(
                status = "SUCCESS",
                message = "Task with ID $taskId updated successfully"
            )
        } catch (e: NotFoundException) {
            throw NotFoundException("Task $taskId not found")
        } catch (e: Exception) {
            throw DBException("Failed to update task with ID: $taskId :: $e")
        }
    }

    override fun deleteProjectTask(taskId: Long): SuccessResponse {
        return try {
            // Fetch the existing task
            val oldTask = taskDao.findTaskById(taskId)
                ?: throw NotFoundException("Task with ID $taskId not found")

            // Update the task status to DELETED
            val updatedTask = oldTask.copy(
                status = Status.DELETED
            )

            // Save the updated task
            taskDao.save(updatedTask)

            // Return success response
            SuccessResponse(
                status = "SUCCESS",
                message = "Task with ID $taskId deleted successfully"
            )
        } catch (e: NotFoundException) {
            throw NotFoundException("Task $taskId not found")
        } catch (e: Exception) {
            throw DBException("Failed to delete task with ID: $taskId", e)
        }
    }



}