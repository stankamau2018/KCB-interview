package ke.co.kcb.crud.domain.entity

data class Project(
    val id:Long?,
    val name:String,
    val description: String
)
