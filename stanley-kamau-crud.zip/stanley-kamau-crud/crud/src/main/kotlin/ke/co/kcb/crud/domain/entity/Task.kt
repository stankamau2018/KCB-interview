package ke.co.kcb.crud.domain.entity

import java.util.Date

data class Task(
    val id:Long?,
    val title:String,
    val description: String,
    val status: String,
    val dueDate: Date,
    val projectId:Long
)
