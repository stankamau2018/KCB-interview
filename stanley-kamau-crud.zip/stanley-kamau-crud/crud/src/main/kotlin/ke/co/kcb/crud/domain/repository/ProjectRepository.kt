package ke.co.kcb.crud.domain.repository

import ke.co.kcb.crud.domain.entity.Project
import ke.co.kcb.crud.domain.entity.Task
import ke.co.kcb.crud.presentatation.Request.ProjectRequest
import ke.co.kcb.crud.presentatation.Request.TaskRequest
import ke.co.kcb.crud.presentatation.SuccessResponse
import java.util.Date

interface ProjectRepository {
    fun fetchAllProjects():List<Project>

    fun fetchProjectById(id:Long): Project

    fun fetchTasksByStatusAndDate(status: String,passedDate:Date): List<Task>

    fun createProject(projectRequest: ProjectRequest): SuccessResponse

    fun createProjectTask(projectId: Long, taskRequest: TaskRequest): SuccessResponse

    fun updateProjectTask(taskId: Long,taskRequest: TaskRequest): SuccessResponse

    fun deleteProjectTask(taskId: Long): SuccessResponse
}