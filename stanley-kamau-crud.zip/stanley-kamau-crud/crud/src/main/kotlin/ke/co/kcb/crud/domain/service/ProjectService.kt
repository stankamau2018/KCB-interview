package ke.co.kcb.crud.domain.service

import ke.co.kcb.crud.data.database.dbo.Status
import ke.co.kcb.crud.domain.entity.Project
import ke.co.kcb.crud.domain.entity.Task
import ke.co.kcb.crud.domain.repository.ProjectRepository
import ke.co.kcb.crud.presentatation.Request.ProjectRequest
import ke.co.kcb.crud.presentatation.Request.TaskRequest
import ke.co.kcb.crud.presentatation.SuccessResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.Date

@Service
class ProjectService(@Autowired val projectRepository: ProjectRepository) {

    fun fetchAllProjects(): List<Project>{
        return projectRepository.fetchAllProjects()
    }

    fun fetchProjectById(id: Long): Project{
        return projectRepository.fetchProjectById(id)
    }

    fun createProject(projectRequest: ProjectRequest): SuccessResponse{
        return  projectRepository.createProject(projectRequest)
    }

    fun createProjectTask(projectId: Long,taskRequest: TaskRequest): SuccessResponse{
        return projectRepository.createProjectTask(projectId,taskRequest)
    }

    fun updateProjectTask(taskId: Long,taskRequest: TaskRequest): SuccessResponse{
        return projectRepository.updateProjectTask(taskId,taskRequest)
    }

    fun deleteProjectTask(taskId: Long): SuccessResponse{
        return projectRepository.deleteProjectTask(taskId)
    }

    fun fetchTaskBystatusAndDuedate(status: Status,duedate:Date): List<Task>{
        return projectRepository.fetchTasksByStatusAndDate(status.toString(),duedate)
    }
}