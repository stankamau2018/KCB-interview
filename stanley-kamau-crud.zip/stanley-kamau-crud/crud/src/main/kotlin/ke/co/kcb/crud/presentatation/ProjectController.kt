package ke.co.kcb.crud.presentatation

import ke.co.kcb.crud.data.database.dbo.Status
import ke.co.kcb.crud.domain.entity.Project
import ke.co.kcb.crud.domain.entity.Task
import ke.co.kcb.crud.domain.service.ProjectService
import ke.co.kcb.crud.presentatation.Request.ProjectRequest
import ke.co.kcb.crud.presentatation.Request.TaskRequest
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.util.Date

@RestController
@RequestMapping("/v1/project")
class ProjectController(@Autowired val projectService: ProjectService) {
    //get all projects
    @GetMapping("", "/")
    fun fetchAllProjects(): List<Project>{
       return projectService.fetchAllProjects()
    }

    //get project by using id
    @GetMapping("/{project_id}", "/{project_id}/")
    fun fetchProjectById(@PathVariable("project_id") projectId: Long): Project {
        return projectService.fetchProjectById(projectId)
    }

    // create a new project
    @PostMapping("","/")
    fun createProject( @Valid @RequestBody projectRequest: ProjectRequest): SuccessResponse{
        return projectService.createProject(projectRequest)

    }
    // create new tasks
    @PostMapping("/{project_id}/tasks","/{project_id}/tasks/")
    fun createProjectTask( @Valid @PathVariable("project_id") projectId: Long, @RequestBody taskRequest: TaskRequest): SuccessResponse{
        return projectService.createProjectTask(projectId,taskRequest)

    }
   // update existing tasks
    @PutMapping("/{task_id}","/{task_id}/")
    fun updateTask(@PathVariable("task_id") taskId: Long, @RequestBody taskRequest: TaskRequest): SuccessResponse{
     return projectService.updateProjectTask(taskId,taskRequest)
    }
    @DeleteMapping("/{task_id}","/{task_id}/")
    fun deleteTask(@PathVariable("task_id") taskId: Long): SuccessResponse{
        return projectService.deleteProjectTask(taskId)

    }

    //get project by using id
    @GetMapping("/{status}/{due_date}", "/{status}/{due_date}/")
    fun fetchTaskByStatusandDueDate(@PathVariable("status") status: Status,@PathVariable("due_date") dueDate: Date): List<Task> {
        return projectService.fetchTaskBystatusAndDuedate(status,dueDate)
    }

}