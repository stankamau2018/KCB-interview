package ke.co.kcb.crud.presentatation.Request

import com.fasterxml.jackson.annotation.JsonProperty
import org.jetbrains.annotations.NotNull

data class ProjectRequest(
    @field:NotNull("Name is required")
    @JsonProperty("name") val name: String,

    @field:NotNull("Description is required")
    @JsonProperty("description") val description: String,
)
