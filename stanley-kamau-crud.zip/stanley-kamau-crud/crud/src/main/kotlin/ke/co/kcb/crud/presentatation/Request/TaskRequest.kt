package ke.co.kcb.crud.presentatation.Request

import com.fasterxml.jackson.annotation.JsonProperty
import org.jetbrains.annotations.NotNull

data class TaskRequest(
    @field:NotNull("title is required")
    @JsonProperty("title") val title: String,

    @field:NotNull("Description is required")
    @JsonProperty("description") val description: String,

    @field:NotNull("Status is required")
    @JsonProperty("status") val status: String,

    @field:NotNull("Due_date  is required")
    @JsonProperty("dueDate") val dueDate: String,
)
