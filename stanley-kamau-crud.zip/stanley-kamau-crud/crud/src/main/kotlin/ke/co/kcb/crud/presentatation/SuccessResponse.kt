package ke.co.kcb.crud.presentatation

import com.fasterxml.jackson.annotation.JsonProperty

data class SuccessResponse(
    @JsonProperty("status") val status: String,
    @JsonProperty("message") val message: String,
)
