package ke.co.kcb.crud.util;

import org.springframework.http.HttpStatus;

public class ApiException extends RuntimeException {

    public HttpStatus status;

    public ApiException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }

    public ApiException(String message) {
        this(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
