package ke.co.kcb.crud.util;

import org.springframework.http.HttpStatus;

public class DBException extends ApiException {

    public DBException(String message) {
        super(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
