package ke.co.kcb.crud

import com.fasterxml.jackson.databind.ObjectMapper
import ke.co.kcb.crud.domain.service.ProjectService
import ke.co.kcb.crud.presentatation.Request.ProjectRequest
import ke.co.kcb.crud.presentatation.SuccessResponse
import org.junit.jupiter.api.Test
import org.mockito.Mockito.`when`
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.mock.mockito.MockBean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.result.MockMvcResultMatchers
import java.awt.PageAttributes.MediaType


@SpringBootTest
class ProjectControllerTest {

	@Autowired
	private lateinit var mockMvc: MockMvc

	@MockBean
	private lateinit var projectService: ProjectService

	@Autowired
	private lateinit var objectMapper: ObjectMapper

	@Test
	fun `should create a new project successfully`() {
		val projectRequest = ProjectRequest(
			name = "New Project",
			description = "Project description"
		)
		val successResponse = SuccessResponse(
			status = "SUCCESS",
			message = "Project created successfully"		)


		`when`(projectService.createProject(projectRequest)).thenReturn(successResponse)

		// Perform POST request
		mockMvc.perform(
			MockMvcRequestBuilders.post("/")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(projectRequest))
		)
			.andExpect(MockMvcResultMatchers.status().isOk)
			.andExpect(MockMvcResultMatchers.jsonPath("$.status").value("SUCCESS"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Project created successfully"))

		verify(projectService, times(1)).createProject(projectRequest)
	}
}
